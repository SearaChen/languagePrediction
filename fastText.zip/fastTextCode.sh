cd fastText-master

./fasttext predict model_langclass.bin text_x_fastinput.csv | tee fasttextpredict.csv
